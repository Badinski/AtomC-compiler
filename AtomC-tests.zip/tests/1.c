/*** primul *** program ***/
void main()
{
	put_s("salut");
}
//sfarsit